package com.example.tebogo_melupe.depressionapp;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;
import com.backendless.persistence.DataQueryBuilder;

import java.util.List;
import java.util.Map;

import static com.example.tebogo_melupe.depressionapp.MyApp.showProgress;

public class AdminLog extends AppCompatActivity {

    private View mProgressView;
    private View mRegisterFormView;
    private TextView tvLoad;

    private EditText email;
    private EditText password;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_log);

        mRegisterFormView = findViewById(R.id.register_form);
        mProgressView = findViewById(R.id.register_progress);
        tvLoad = findViewById(R.id.tvLoad);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("ADMIN LOGIN");

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String emailAddress = email.getText().toString();
                String pwd = password.getText().toString();

                loginUser(emailAddress, pwd);
            }
        });

    }

    private void loginUser(final String emailAddress, String pwd){
            // Construct the query to search for the user with the provided username, password, and role
        String whereClause = "email = 'tebogo@gmail.com' AND pwd = '1234'";

        DataQueryBuilder queryBuilder = DataQueryBuilder.create();
            queryBuilder.setWhereClause(whereClause);

            // Query the Backendless 'UserLogin' table
            Backendless.Data.of("Admin").find(queryBuilder, new AsyncCallback<List<Map>>() {
                @Override
                public void handleResponse(List<Map> foundUsers) {
                    if (foundUsers.size() > 0) {

//                        Map<String, Object> currentUser = foundUsers.get(0);  // Assuming one match
//                        String currentEmail = (String) currentUser.get("email");

                        // User found, login successful
                        Toast.makeText(AdminLog.this, "Login successful!", Toast.LENGTH_SHORT).show();


                        Intent intent = new Intent(AdminLog.this, AdminMenu.class);
                        //intent.putExtra("email", currentEmail);

                        startActivity(intent);

                    } else {
                        // User not found or incorrect credentials
                        Toast.makeText(AdminLog.this, "Invalid credentials or role!", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void handleFault(BackendlessFault fault) {
                    // Handle error
                    Toast.makeText(AdminLog.this, "Error: " + fault.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
    }

}
