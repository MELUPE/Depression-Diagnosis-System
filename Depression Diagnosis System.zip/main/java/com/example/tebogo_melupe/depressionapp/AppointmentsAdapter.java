package com.example.tebogo_melupe.depressionapp;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;


public class AppointmentsAdapter extends RecyclerView.Adapter<AppointmentsAdapter.ViewHolder> {

    private List<userAppointment> appointmentList;

    public AppointmentsAdapter(List<userAppointment> appointmentList) {
        this.appointmentList = appointmentList;
    }

    public AppointmentsAdapter(ViewAppointment viewAppointment, int simple_list_item_1, List<String> appointments) {
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.appointment_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        userAppointment appointment = appointmentList.get(position);
        holder.textViewDate.setText(appointment.getDate());
        holder.textViewTime.setText(appointment.getTime());
        holder.textViewUser.setText(appointment.getUser());
    }

    @Override
    public int getItemCount() {
        return appointmentList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewDate, textViewTime, textViewUser;

        public ViewHolder(android.view.View itemView) {
            super(itemView);
            textViewDate = itemView.findViewById(R.id.textViewDate);
            textViewTime = itemView.findViewById(R.id.textViewTime);
            textViewUser = itemView.findViewById(R.id.textViewUser);
        }
    }
}
