package com.example.tebogo_melupe.depressionapp;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class History extends AppCompatActivity {

    private ListView lvHistory;
    private ArrayAdapter<String> adapter;
    private List<Map> resultsList;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.refresh) {
            // Call the method to handle the refresh action
            refreshContent();
            Toast.makeText( this, "Refresh clicked", Toast.LENGTH_SHORT ).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void refreshContent() {
        // Implement your refresh logic here
        Toast.makeText(this, "Content refreshed" + System.currentTimeMillis(), Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        lvHistory = findViewById(R.id.lvHistory);
        resultsList = new ArrayList<>();

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("HISTORY");



        Backendless.Data.of("Results").find(new AsyncCallback<List<Map>>() {
            @Override
            public void handleResponse(List<Map> response) {
                resultsList.addAll(response);
                List<String> results = new ArrayList<>();
                for (Map result : response) {
                    String display = "Date: " + result.get("date") + ", Score: " + result.get("score");
                    results.add(display);
                }
                adapter = new ArrayAdapter<>(History.this, android.R.layout.simple_list_item_1, results);
                lvHistory.setAdapter(adapter);
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(History.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        lvHistory.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                Map resultToDelete = resultsList.get(position);
                Backendless.Data.of("Results").remove(resultToDelete, new AsyncCallback<Long>() {
                    @Override
                    public void handleResponse(Long response) {
                        resultsList.remove(position);
                        adapter.remove(adapter.getItem(position));
                        Toast.makeText(History.this, "Result deleted", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void handleFault(BackendlessFault fault) {
                        Toast.makeText(History.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
                return true;
            }
        });
    }
}
