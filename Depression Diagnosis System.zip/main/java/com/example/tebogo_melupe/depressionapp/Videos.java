package com.example.tebogo_melupe.depressionapp;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Videos extends AppCompatActivity {

    private RecyclerView recyclerView;
    private VideoAdapter adapter;
    private List<Video> videos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videos);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("VIDEOS");

        videos = new ArrayList<Video>();
        videos.add(new Video("5 ONE-MINUTE Habits to Beat DEPRESSION", "https://www.youtube.com/watch?v=HXLQLy1c2tU"));
        videos.add(new Video("FIGHT DEPRESSION - Powerful Study Motivation [2018]", "https://www.youtube.com/watch?v=1I9ADpXbD6c"));
        videos.add(new Video(" OVERCOME DEPRESSION - Powerful Motivational Speech Video (Featuring Dr. Jessica Houston)", "https://www.youtube.com/watch?v=1I9ADpXbD6c"));
        videos.add(new Video("5 Ways to Overcome Depression - My Experience", "https://www.youtube.com/watch?v=zJhaEc2bFO0"));
        videos.add(new Video("Depression Explained (Major Depressive Disorder)", "https://www.youtube.com/watch?v=tJQRsIbD110"));
        videos.add(new Video("What is Depression?", "https://www.youtube.com/watch?v=fWFuQR_Wt4M"));


        adapter = new VideoAdapter(this, videos);
        recyclerView.setAdapter(adapter);
    }
}
