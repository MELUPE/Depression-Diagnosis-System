package com.example.tebogo_melupe.depressionapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Questionnaire extends AppCompatActivity {

    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionnaire);


        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int score = calculateScore();
                saveResultsToDatabase(score);
                Intent intent = new Intent(Questionnaire.this, Results.class);
                intent.putExtra("score", score);
                startActivity(intent);
            }
        });
    }
    private int calculateScore() {
        int score = 0;
        // Example calculation for one question
        RadioGroup radioGroupQ1 = findViewById(R.id.radioGroupQ1);
        int selectedIdQ1 = radioGroupQ1.getCheckedRadioButtonId();
        RadioGroup radioGroupQ2 = findViewById(R.id.radioGroupQ2);
        int selectedIdQ2 = radioGroupQ2.getCheckedRadioButtonId();
        RadioGroup radioGroupQ3 = findViewById(R.id.radioGroupQ3);
        int selectedIdQ3 = radioGroupQ3.getCheckedRadioButtonId();
        RadioGroup radioGroupQ4 = findViewById(R.id.radioGroupQ4);
        int selectedIdQ4 = radioGroupQ4.getCheckedRadioButtonId();
        RadioGroup radioGroupQ5 = findViewById(R.id.radioGroupQ5);
        int selectedIdQ5 = radioGroupQ5.getCheckedRadioButtonId();
        RadioGroup radioGroupQ6 = findViewById(R.id.radioGroupQ6);
        int selectedIdQ6 = radioGroupQ6.getCheckedRadioButtonId();
        RadioGroup radioGroupQ7 = findViewById(R.id.radioGroupQ7);
        int selectedIdQ7 = radioGroupQ7.getCheckedRadioButtonId();
        RadioGroup radioGroupQ8 = findViewById(R.id.radioGroupQ8);
        int selectedIdQ8 = radioGroupQ8.getCheckedRadioButtonId();


        if (selectedIdQ1 != -1) {
            RadioButton selectedRadioButton = findViewById(selectedIdQ1);
            switch (selectedRadioButton.getId()) {
                case R.id.rbQ1A0:
                    score += 0;
                    break;
                case R.id.rbQ1A1:
                    score += 1;
                    break;
                case R.id.rbQ1A2:
                    score += 2;
                    break;
                case R.id.rbQ1A3:
                    score += 3;
                    break;
            }
        }
        if (selectedIdQ2 != -1) {
            RadioButton selectedRadioButton = findViewById(selectedIdQ2);
            switch (selectedRadioButton.getId()) {
                case R.id.rbQ2A0:
                    score += 0;
                    break;
                case R.id.rbQ2A1:
                    score += 1;
                    break;
                case R.id.rbQ2A2:
                    score += 2;
                    break;
                case R.id.rbQ2A3:
                    score += 3;
                    break;
            }
        }

        if (selectedIdQ3 != -1) {
            RadioButton selectedRadioButton = findViewById(selectedIdQ3);
            switch (selectedRadioButton.getId()) {
                case R.id.rbQ3A0:
                    score += 0;
                    break;
                case R.id.rbQ3A1:
                    score += 1;
                    break;
                case R.id.rbQ3A2:
                    score += 2;
                    break;
                case R.id.rbQ3A3:
                    score += 3;
                    break;
            }
        }

        if (selectedIdQ4 != -1) {
            RadioButton selectedRadioButton = findViewById(selectedIdQ4);
            switch (selectedRadioButton.getId()) {
                case R.id.rbQ4A0:
                    score += 0;
                    break;
                case R.id.rbQ4A1:
                    score += 1;
                    break;
                case R.id.rbQ4A2:
                    score += 2;
                    break;
                case R.id.rbQ4A3:
                    score += 3;
                    break;
            }
        }
        if (selectedIdQ5 != -1) {
            RadioButton selectedRadioButton = findViewById(selectedIdQ5);
            switch (selectedRadioButton.getId()) {
                case R.id.rbQ5A0:
                    score += 0;
                    break;
                case R.id.rbQ5A1:
                    score += 1;
                    break;
                case R.id.rbQ5A2:
                    score += 2;
                    break;
                case R.id.rbQ5A3:
                    score += 3;
                    break;
            }
        }

        if (selectedIdQ6 != -1) {
            RadioButton selectedRadioButton = findViewById(selectedIdQ6);
            switch (selectedRadioButton.getId()) {
                case R.id.rbQ6A0:
                    score += 0;
                    break;
                case R.id.rbQ6A1:
                    score += 1;
                    break;
                case R.id.rbQ6A2:
                    score += 2;
                    break;
                case R.id.rbQ6A3:
                    score += 3;
                    break;
            }
        }
        if (selectedIdQ7 != -1) {
            RadioButton selectedRadioButton = findViewById(selectedIdQ7);
            switch (selectedRadioButton.getId()) {
                case R.id.rbQ7A0:
                    score += 0;
                    break;
                case R.id.rbQ7A1:
                    score += 1;
                    break;
                case R.id.rbQ7A2:
                    score += 2;
                    break;
                case R.id.rbQ7A3:
                    score += 3;
                    break;
            }
        }
        if (selectedIdQ8 != -1) {
            RadioButton selectedRadioButton = findViewById(selectedIdQ8);
            switch (selectedRadioButton.getId()) {
                case R.id.rbQ8A0:
                    score += 0;
                    break;
                case R.id.rbQ8A1:
                    score += 1;
                    break;
                case R.id.rbQ8A2:
                    score += 2;
                    break;
                case R.id.rbQ8A3:
                    score += 3;
                    break;
            }
        }
        // Repeat for all other questions
        return score;
    }

    private void saveResultsToDatabase(int score) {
        Map<String, Object> result = new HashMap<>();
        result.put("score", score);
        result.put("userId", Backendless.UserService.CurrentUser().getUserId());
        result.put("date", new Date());

        Backendless.Data.of("Results").save(result, new AsyncCallback<Map>() {
            @Override
            public void handleResponse(Map response) {
                Toast.makeText(Questionnaire.this, "Results saved", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Questionnaire.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
