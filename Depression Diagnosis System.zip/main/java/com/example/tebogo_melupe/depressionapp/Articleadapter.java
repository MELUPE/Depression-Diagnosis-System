package com.example.tebogo_melupe.depressionapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class Articleadapter extends RecyclerView.Adapter<Articleadapter.ArticleViewHolder> {

    private List<Article> articles;
    private Context context;

    Articleadapter(Context context,List<Article> articles) {
        this.articles = articles;
        this.context = context;
    }

    @NonNull
    @Override
    public Articleadapter.ArticleViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_article, viewGroup, false);
        return new ArticleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Articleadapter.ArticleViewHolder articleViewHolder, int i) {

        final Article article = articles.get(i);
        articleViewHolder.tvTitle.setText(article.getTitle());
        //articleViewHolder.tvUrl.setText(article.getUrl());
        articleViewHolder.imageView.setImageResource(R.drawable.document);
        articleViewHolder.itemView.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(article.getUrl()));
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                context.startActivity(intent);
            }
        } );
    }

    @Override
    public int getItemCount() {
        return articles.size();
    }

    public class ArticleViewHolder extends RecyclerView.ViewHolder {

        TextView tvTitle, tvUrl;
        ImageView imageView;

        public ArticleViewHolder(@NonNull View itemView) {
            super( itemView );

            tvTitle = itemView.findViewById(R.id.tvTitle);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}
