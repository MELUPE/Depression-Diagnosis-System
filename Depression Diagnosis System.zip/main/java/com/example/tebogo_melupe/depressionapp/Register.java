package com.example.tebogo_melupe.depressionapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

import java.util.Calendar;

import static com.example.tebogo_melupe.depressionapp.MyApp.showProgress;

public class Register extends AppCompatActivity {

    private View mProgressView;
    private View mRegisterFormView;
    private TextView tvLoad;

    private EditText fullName, dateOfBirth, email, password, retypePassword, phone;
    private RadioGroup genderGroup;
    private Button registerButton;
    private Calendar calendar;
    private DatePickerDialog datePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("REGISTER");

        mRegisterFormView = findViewById(R.id.register_form);
        mProgressView = findViewById(R.id.register_progress);
        tvLoad = findViewById(R.id.tvLoad);

        registerButton = findViewById(R.id.registerButton);
        fullName = findViewById(R.id.fullName);
        dateOfBirth = findViewById(R.id.dateOfBirth);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        retypePassword = findViewById(R.id.retypePassword);
        phone = findViewById(R.id.phone);
        genderGroup = findViewById(R.id.genderGroup);
        registerButton = findViewById(R.id.registerButton);

        dateOfBirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

    }

    private void showDatePicker()
    {
        calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get((Calendar.MONTH));
        int year = calendar.get(Calendar.YEAR);

        datePickerDialog = new DatePickerDialog(Register.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                dateOfBirth.setText(dayOfMonth + "/" + (month + 1) +"/" + year);
            }
        }, year, month, day);
        datePickerDialog.show();
    }

    private void registerUser()
    {
        String name = fullName.getText().toString();
        String dob = dateOfBirth.getText().toString();
        String emailAddress = email.getText().toString();
        String pwd = password.getText().toString();
        String rePwd = retypePassword.getText().toString();
        String phoneNumber = phone.getText().toString();
        int selectedGenderId = genderGroup.getCheckedRadioButtonId();
        RadioButton selectedGender = findViewById(selectedGenderId);
        String gender = selectedGender.getText().toString();

        if (!pwd.equals(rePwd)) {
            Toast.makeText(this, "Passwords do not match!", Toast.LENGTH_SHORT).show();
            return;
        }

        BackendlessUser user = new BackendlessUser();
        user.setProperty("name", name);
        user.setProperty("dob", dob);
        user.setProperty("gender", gender);
        user.setProperty("email", emailAddress);
        user.setPassword(pwd);
        user.setProperty("phone", phoneNumber);

        showProgress(true, mProgressView, mRegisterFormView, tvLoad,
                getApplicationContext());


        Backendless.UserService.register(user, new AsyncCallback<BackendlessUser>() {
            @Override
            public void handleResponse(BackendlessUser registeredUser) {
                Toast.makeText(Register.this, "User Registered Successfully!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Register.this, Login.class);
                startActivity(intent);
                Register.this.finish();
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Register.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
