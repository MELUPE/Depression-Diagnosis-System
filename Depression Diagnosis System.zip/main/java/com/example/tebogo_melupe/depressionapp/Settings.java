package com.example.tebogo_melupe.depressionapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Settings extends AppCompatActivity {

    private RadioGroup radioGroupColors;
    private RadioButton radioButtonRed, radioButtonBlue, radioButtonGreen;
    private Button buttonSave;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize UI components
        radioGroupColors = findViewById(R.id.radioGroupColors);
        radioButtonRed = findViewById(R.id.radioButtonRed);
        radioButtonBlue = findViewById(R.id.radioButtonBlue);
        radioButtonGreen = findViewById(R.id.radioButtonGreen);
        buttonSave = findViewById(R.id.buttonSave);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("ThemePreferences", MODE_PRIVATE);

        // Load saved theme
        loadSavedTheme();

        // Set up save button listener
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(Settings.this, "Theme Successfully Changed!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Settings.this, Main.class);
                startActivity(intent);
                saveSelectedTheme();
            }
        });
    }

    private void loadSavedTheme() {
        String savedTheme = sharedPreferences.getString("selectedTheme", "Orange");
        switch (savedTheme) {
            case "Orange":
                radioButtonRed.setChecked(true);
                break;
            case "Red":
                radioButtonRed.setChecked(true);
                break;
            case "Blue":
                radioButtonBlue.setChecked(true);
                break;
            case "Green":
                radioButtonGreen.setChecked(true);
                break;
        }
    }

    private void saveSelectedTheme() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        int selectedId = radioGroupColors.getCheckedRadioButtonId();
        String selectedTheme = "Orange"; // default

        if (selectedId == radioButtonRed.getId()) {
            selectedTheme = "Red";
        } else if (selectedId == radioButtonBlue.getId()) {
            selectedTheme = "Blue";
        } else if (selectedId == radioButtonGreen.getId()) {
            selectedTheme = "Green";
        }
        else if (selectedId == radioButtonGreen.getId()) {
            selectedTheme = "Orange";
        }

        editor.putString("selectedTheme", selectedTheme);
        editor.apply();

        // Apply the theme change
        applyTheme(selectedTheme);
    }
    private void applyTheme(String theme) {
        // Code to change the theme of the app
        // This can include setting colors, styles, etc. based on the selected theme
        // For example:
        if (theme.equals("Red")) {
            setTheme(R.style.Theme_Red);
        } else if (theme.equals("Blue")) {
            setTheme(R.style.Theme_Blue);
        } else if (theme.equals("Green")) {
            setTheme(R.style.Theme_Green);
        }
        else if (theme.equals("Orange")) {
            setTheme(R.style.AppTheme);
        }

        // Recreate the activity to apply the new theme
        recreate();
    }
}
