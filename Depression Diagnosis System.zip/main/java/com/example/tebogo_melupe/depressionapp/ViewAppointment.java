package com.example.tebogo_melupe.depressionapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ViewAppointment extends AppCompatActivity {

    private RecyclerView appointmentsRecyclerView;
    private AppointmentsAdapter appointmentsAdapter;
    private ArrayList<Map> appointmentsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_appointment);

        appointmentsRecyclerView = findViewById(R.id.recyclerView);
        appointmentsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        Backendless.Data.of("Appointments").find(new AsyncCallback<List<Map>>() {
            @Override
            public void handleResponse(List<Map> response) {
                //appointmentsList.addAll(response);
                //boolean add = appointmentsList.add((Map) response);
                List<String> appointments = new ArrayList<>();
                for (Map appointment : response) {
                    String display = "email: " + ", full Names: " + appointment.get("fullName") + ", Branch: " + appointment.get("branch") + ", Contact number: " + appointment.get("phoneNumber") +
                            ", Date: " + appointment.get("AppDate") + ", Time: " + appointment.get("AppTime");
                    appointments.add(display);
                }
                //appointmentsAdapter = new AppointmentsAdapter<>(ViewAppointment.this, android.R.layout.simple_list_item_1, appointments);
                appointmentsAdapter = new AppointmentsAdapter(ViewAppointment.this, android.R.layout.simple_list_item_1, appointments);
                appointmentsRecyclerView.setAdapter(appointmentsAdapter);
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(ViewAppointment.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }

}
