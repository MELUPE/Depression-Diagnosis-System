package com.example.tebogo_melupe.depressionapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

public class Main extends AppCompatActivity {

    private View mProgressView;
    private View mRegisterFormView;
    private TextView tvLoad;
    private SharedPreferences sharedPreferences;

    private TextView tvWelcome;
    CardView cdQuestionnaire, cdAppointment, cdGroup, cdVideo, cdbrouche;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        sharedPreferences = getSharedPreferences("ThemePreferences", MODE_PRIVATE);
        String savedTheme = sharedPreferences.getString("selectedTheme", "Orange");
        applyTheme(savedTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mRegisterFormView = findViewById(R.id.register_form);
        mProgressView = findViewById(R.id.register_progress);
        tvLoad = findViewById(R.id.tvLoad);

        tvWelcome = findViewById(R.id.tvWelcome);
        cdQuestionnaire = findViewById(R.id.cdQuestionnaire);
        cdAppointment = findViewById(R.id.cdAppointment);
        cdGroup = findViewById( R.id.cdGroup );
        cdVideo = findViewById( R.id.cdVideo );
        cdbrouche = findViewById( R.id.cdBrouche );

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("MAIN MENU");

        BackendlessUser currentUser = Backendless.UserService.CurrentUser();
        if (currentUser != null)
        {
            String username = (String) currentUser.getProperty("name");
            tvWelcome.setText(username);
        }

        cdQuestionnaire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Main.this, Questionnaire.class));
            }
        });

        cdAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main.this, Appointment.class);
                intent.putExtra("name", "email");
                startActivity(intent);
            }
        });

        cdGroup.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.microsoft.com/en-za/microsoft-teams/group-chat-software";

                // Create an Intent to open the URL
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData( Uri.parse(url));

                // Start the activity
                startActivity(intent);
            }
        } );

        cdVideo.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Main.this, Videos.class));
            }
        } );

        cdbrouche.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Main.this, Articles.class));
            }
        } );


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.history, menu);
        getMenuInflater().inflate(R.menu.item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.history) {
            Intent intent = new Intent(this, History.class);
            startActivity(intent);
            return true;
        }
        if (id == R.id.logout) {
            tvLoad.setText("Logging you out...please wait...");

            Backendless.UserService.logout(new AsyncCallback<Void>()
            {
                @Override
                public void handleResponse(Void response)
                {
                    Toast.makeText(Main.this, "Successfully logged you out.", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Main.this, Welcome.class));
                }

                @Override
                public void handleFault(BackendlessFault fault)
                {
                    Toast.makeText(Main.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
            ;
            return true;
        }
        if (id == R.id.setting) {
            startActivity(new Intent(Main.this, com.example.tebogo_melupe.depressionapp.Settings.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void applyTheme(String theme) {
        if (theme.equals("Red")) {
            setTheme(R.style.Theme_Red);
        } else if (theme.equals("Blue")) {
            setTheme(R.style.Theme_Blue);
        } else if (theme.equals("Green")) {
            setTheme(R.style.Theme_Green);
        }
        else if (theme.equals("Orange")) {
            setTheme(R.style.AppTheme);
        }
    }
}
