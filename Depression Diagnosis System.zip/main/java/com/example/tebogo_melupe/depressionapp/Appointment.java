package com.example.tebogo_melupe.depressionapp;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class Appointment extends AppCompatActivity {

    private EditText editTextFullName, editTextEmail, editTextPhone;
    private Spinner spinnerBranch;
    private Button buttonSelectDate, buttonSelectTime, buttonBookAppointment;
    private TextView textViewSelectedDate, textViewSelectedTime;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_appointment);
        editTextFullName = findViewById(R.id.editTextFullName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPhone = findViewById(R.id.editTextPhone);
        spinnerBranch = findViewById(R.id.spinnerBranch);
        buttonSelectDate = findViewById(R.id.buttonSelectDate);
        buttonSelectTime = findViewById(R.id.buttonSelectTime);
        buttonBookAppointment = findViewById(R.id.buttonBookAppointment);
        textViewSelectedDate = findViewById(R.id.textViewSelectedDate);
        textViewSelectedTime = findViewById(R.id.textViewSelectedTime);

        calendar = Calendar.getInstance();

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("SCHEDULE APPOINTMENT");

        buttonSelectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(Appointment.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String selectedDate = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                        textViewSelectedDate.setText(selectedDate);
                    }
                }, year, month, day);
                datePickerDialog.show();
            }
        });

        buttonSelectTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);
                TimePickerDialog timePickerDialog = new TimePickerDialog(Appointment.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        String selectedTime = hourOfDay + ":" + minute;
                        textViewSelectedTime.setText(selectedTime);
                    }
                }, hour, minute, true);
                timePickerDialog.show();
            }
        });

        buttonBookAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String fullName = editTextFullName.getText().toString().trim();
                final String email = editTextEmail.getText().toString().trim();
                final String phone = editTextPhone.getText().toString().trim();
                final String branch = spinnerBranch.getSelectedItem().toString();
                final String selectedDate = textViewSelectedDate.getText().toString();
                final String selectedTime = textViewSelectedTime.getText().toString();

                if (fullName.isEmpty() || email.isEmpty() || phone.isEmpty() || selectedDate.equals("Selected Date") || selectedTime.equals("Selected Time")) {
                    Toast.makeText(Appointment.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                HashMap<String, Object> appointment = new HashMap<>();
                appointment.put("fullName", fullName);
                appointment.put("email", email);
                appointment.put("phoneNumber", phone);
                appointment.put("branch", branch);
                appointment.put("AppDate", selectedDate);
                appointment.put("AppTime", selectedTime);


                Backendless.Data.of("Appointments").save(appointment, new AsyncCallback<Map>() {
                    @Override
                    public void handleResponse(Map response) {
                        Toast.makeText(Appointment.this, "Appointment booked successfully!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(Appointment.this, Main.class);
                        startActivity(intent);

                    }

                    @Override
                    public void handleFault(BackendlessFault fault) {
                        Toast.makeText(Appointment.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

            }

        });
    }
}
