package com.example.tebogo_melupe.depressionapp;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

import static com.example.tebogo_melupe.depressionapp.MyApp.showProgress;

public class Login extends AppCompatActivity {

    private View mProgressView;
    private View mRegisterFormView;
    private TextView tvLoad;

    private EditText email, password;
    private Button loginButton;
    private TextView forgotPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mRegisterFormView = findViewById(R.id.register_form);
        mProgressView = findViewById(R.id.register_progress);
        tvLoad = findViewById(R.id.tvLoad);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("LOGIN");

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        forgotPassword = findViewById(R.id.forgotPassword);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetPassword();
            }
        });
    }

    private void loginUser() {
        String emailAddress = email.getText().toString();
        String pwd = password.getText().toString();

        Backendless.UserService.login(emailAddress, pwd, new AsyncCallback<BackendlessUser>() {
            @Override
            public void handleResponse(BackendlessUser user) {

                showProgress(true, mProgressView, mRegisterFormView, tvLoad,
                        getApplicationContext());

                Toast.makeText(Login.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                // Navigate to another activity (e.g., MainActivity)
                Intent intent = new Intent(Login.this, Main.class);
                startActivity(intent);
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Login.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void resetPassword() {
        final String emailAddress = email.getText().toString();

        Backendless.UserService.restorePassword(emailAddress, new AsyncCallback<Void>() {
            @Override
            public void handleResponse(Void response) {

                showProgress(true, mProgressView, mRegisterFormView, tvLoad,
                        getApplicationContext());
                Intent intent = new Intent(Login.this, ForgotPassword.class);
                startActivity(intent);

            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Login.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
