package com.example.tebogo_melupe.depressionapp;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class Results extends AppCompatActivity {

    private TextView tvScore, tvInterpretation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        tvScore = findViewById(R.id.tvScore);
        tvInterpretation = findViewById(R.id.tvInterpretation);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("RESULTS");

        int score = getIntent().getIntExtra("score", 0);
        tvScore.setText("Score: " + score);
        tvInterpretation.setText(getInterpretation(score));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.home) {
            Intent intent = new Intent(this, Main.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private String getInterpretation(int score) {
        if (score <= 4) {
            return "Healthy Mindset";
        } else if (score <= 9) {
            return "Mild Depression";
        } else if (score <= 14) {
            return "Moderate Depression";
        } else if (score <= 19) {
            return "Moderately Severe Depression";
        } else {
            return "Severe Depression";
        }
    }


}
